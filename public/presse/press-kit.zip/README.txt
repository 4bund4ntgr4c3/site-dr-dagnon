Dossier de presse — Dr. Seynudé Jean-Fortuné Dagnon
==================================================

Contenu du dossier :
  bio-fr.txt / bio-en.txt   Biographie longue (bilingue)
  bio-courte-fr.txt / bio-courte-en.txt   Biographie courte (1-2 phrases)
  contact.txt               Coordonnées et réseaux
  portrait.webp             Photo de portrait (libre de droits pour la presse)

Site web : https://seynudedagnon.com
